import tkinter as tk
import winsound
import math
import random
import os
try:
    from PIL import Image, ImageTk
except:
    print('PLEASE INSTALL :pillow" PYTHON MODULE')
    a=input(': ')
class Bullet:
    def __init__(self,xMov,yMov,xVal,yVal,spd):


        self.x = 250+(xMov*25*xVal)
        self.y = 250+(yMov*25*yVal)
        self.speed = spd
        self.xMov = xMov
        self.yMov = yMov
        self.xVal = xVal
        self.yVal = yVal
    def move(self):
        self.x += (self.xMov*self.xVal)*self.speed
        self.y += (self.yMov*self.yVal)*self.speed

class Enemy:
    def __init__(self,spd):
        self.image = Image.open('tank.png')
        self.x = random.randint(1,499)
        self.y = random.choice([-10,510])
        self.speed = spd
        self.xVal = 0
        self.yVal = 0
        if self.x < 250:
            adj = 250 - self.x
            self.xVal = 1
        else:
            adj = self.x - 250
            self.xVal = -1
        if self.y < 250:
            opp = 250 - self.y
            self.yVal = 1
        else:
            opp = self.y - 250
            self.yVal = -1

        hyp = math.sqrt((opp * opp) + (adj * adj))

        self.xMov = (adj / hyp)
        self.yMov = (opp / hyp)
        if self.xVal < 0 and self.yVal < 0:
            self.image = self.image.rotate(((math.asin(self.xMov)*180)/math.pi))
        elif self.xVal > 0 and self.yVal < 0:
            self.image = self.image.rotate(-((math.asin(self.xMov)*180)/math.pi))
        elif self.xVal > 0 and self.yVal > 0:
            self.image = self.image.rotate(((math.asin(self.xMov)*180)/math.pi)+180)
        elif self.xVal < 0 and self.yVal > 0:
            self.image = self.image.rotate(-((math.asin(self.xMov)*180)/math.pi)+180)
        self.drawImage = ImageTk.PhotoImage(self.image)
    def move(self):



        self.x += (self.xMov*self.speed)*self.xVal
        self.y += (self.yMov*self.speed)*self.yVal


class App:
    def __init__(self):




        self.root = tk.Tk()
        self.root.geometry('{}x{}'.format( '500', '500'))
        self.root.resizable(width=False,height=False)
        self.cursor = tk.PhotoImage(file='./pointer.png')
        self.backDrop = tk.PhotoImage(file='./grass.png')
        self.explosion = tk.PhotoImage(file='./explosion.png')
        self.base = tk.PhotoImage(file='./turretbase.png')
        self.px = 0
        self.py = 0
        self.level = 1
        self.paused = False



        self.c1 = tk.Canvas(self.root)
        self.c1.pack()
        self.c1.place(width='500',height='500',x=0,y=0)
        self.c1.config(bg='Black',cursor='none')



        self.bullet = None
        self.enemies = []
        self.enemyCap = 2
        self.score = 0
        self.gscore = 0
        self.health = 100
        self.espd = 0.3
        self.bspd = 3
        self.scaleFac = 50
        self.delayTime = 1
        self.draw()
        self.turret = Image.open('turret.png')

        self.drawTurret = ImageTk.PhotoImage(self.turret)
        self.c1.bind('<Motion>', self.motion)
        self.c1.bind('<Button-1>', self.fire)
        self.root.bind('<space>',self.pause)

    def pause(self,*args):

        if self.paused == False:
            self.paused = True
            self.c1.create_text(250,250,text='PAUSED',fill='White',font='fixedsys 14 bold')
        else:
            self.paused = False
            self.draw()
    def motion(self,event):
        self.px,self.py = event.x,event.y


    def fire(self,*args):
        if self.paused == True:
            return
        x,y,V,Y = self.calcAngle()
        if self.bullet == None:
            winsound.PlaySound('shoot2.wav',winsound.SND_ASYNC)
            self.bullet = Bullet(x,y,V,Y,self.bspd)

        else:
            return
    def calcAngle(self):
        self.turret = Image.open('turret.png')
        self.delayTime = 1
        #self.c1.create_line(250,250,self.px,self.py)
        xVal = 0
        yVal = 0
        if self.px < 250:
            adj = 250-self.px
            xVal = -1
        else:
            adj = self.px-250
            xVal = 1
        if self.py <250:
            opp = 250-self.py
            yVal = -1
        else:
            opp = self.py-250
            yVal = 1

        hyp = math.sqrt((opp*opp)+(adj*adj))

        x = (adj/hyp)
        y = (opp/hyp)
        if xVal < 0 and yVal < 0:
            self.turret = self.turret.rotate(((math.asin(x)*180)/math.pi))
        elif xVal > 0 and yVal < 0:
            self.turret = self.turret.rotate(-((math.asin(x)*180)/math.pi))
        elif xVal > 0 and yVal > 0:
            self.turret = self.turret.rotate(((math.asin(x)*180)/math.pi)+180)
        elif xVal < 0 and yVal > 0:
            self.turret = self.turret.rotate(-((math.asin(x)*180)/math.pi)+180)
        self.drawTurret = ImageTk.PhotoImage(self.turret)
        return(x,y,xVal,yVal)

            #print(opp/adj)
    def draw(self):
        if self.paused == True:
            return
        if self.score > self.scaleFac:
            self.health = 100
            self.scaleFac += int(self.scaleFac)
            self.enemyCap +=1
            self.score = 0
            self.level += 1
            if self.espd < 1:
                self.espd+=0.05
                self.bspd += 0.2
        self.c1.delete('all')
        self.c1.create_image(250,250,image=self.backDrop)

        x,y,xVal,yVal = self.calcAngle()
        self.c1.create_image(250, 250,image=self.base)
        self.c1.create_image(250,250,image=self.drawTurret)

        if self.bullet != None:
            self.bullet.move()

            self.c1.create_oval(self.bullet.x-5,self.bullet.y-5,self.bullet.x+5,self.bullet.y+5,fill='Black')
            if self.bullet.x < 0 or self.bullet.x > 500 or self.bullet.y < 0 or self.bullet.y > 500:
                self.bullet = None

        while len(self.enemies) != self.enemyCap:
            enemy = Enemy(self.espd)
            self.enemies.append(enemy)
        for i in range(len(self.enemies)):
            if i > len(self.enemies)-1:
                break
            self.enemies[i].move()
            if self.enemies[i].x > 230 and self.enemies[i].x < 270 and self.enemies[i].y > 230 and self.enemies[i].y < 270:
                self.health -= 10
                del self.enemies[i]
                continue
           #self.c1.create_image(self.enemies[i].x,self.enemies[i].y)
            self.c1.create_image(self.enemies[i].x,self.enemies[i].y,image=self.enemies[i].drawImage)
            if self.bullet != None :
                if self.bullet.x > self.enemies[i].x -10 and self.bullet.x < self.enemies[i].x+10 and self.bullet.y > self.enemies[i].y -10 and self.bullet.y < self.enemies[i].y+10:
                    self.bullet =None
                    self.c1.create_image(self.enemies[i].x,self.enemies[i].y,image=self.explosion)
                    self.delayTime = 50
                    winsound.PlaySound(random.choice(['Explosion.wav','explosion2.wav','shoot.wav']),winsound.SND_ASYNC)
                    del self.enemies[i]

                    self.score+=10
                    self.gscore += 10
        self.c1.create_rectangle(20, 10, 20 + (self.health * 2), 30, fill='Red')
        self.c1.create_text(50,20,text=str(self.health)+'/100',fill='White',font="fixedsys 9")

        self.c1.create_text(59, 40, text='Score: '+str(self.gscore),fill='White',font='fixedsys 9 bold')
        self.c1.create_text(59, 60, text='Level: ' + str(self.level), fill='White', font='fixedsys 9 bold')
        self.c1.create_image(self.px, self.py, image=self.cursor)
        if self.health > 0:
            self.root.after(self.delayTime,self.draw)
        else:
            self.c1.delete('all')
            self.c1.create_text(250,250,text='YOU LOSE',fill='White',font='fixedsys 14 bold')
            self.c1.create_text(250,270,text='Score: '+str(self.gscore),fill='White',font='fixedsys 14 bold')
            self.c1.create_text(250, 290, text='Level: ' + str(self.level), fill='White', font='fixedsys 14 bold')



app = App()


app.root.mainloop()